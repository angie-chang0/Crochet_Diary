from cmu_graphics import *
def getClosestPoint(app):
    for closestPointIndex in range(len(app.graphDots)):
        if app.selectedStitchIndex != None:
            (dotX, dotY) = app.graphDots[closestPointIndex]
            (stitchX, stitchY) = app.centers[app.selectedStitchIndex]
            Rotation = app.rotation[app.selectedStitchIndex]
            # chain
            if app.stitchList[app.selectedStitchIndex] == 'chain':
                if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                    stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                    if Rotation == 3:
                        app.centers[app.selectedStitchIndex] = (dotX+15, (dotY))
                    elif Rotation == 4  or Rotation == 2:
                        app.centers[app.selectedStitchIndex] = (dotX+15, (dotY-15))
                    elif Rotation == 1  or Rotation == 5:
                        app.centers[app.selectedStitchIndex] = (dotX+15, (dotY+15))
                    else:
                        app.centers[app.selectedStitchIndex] = (dotX, (dotY+15))
            # ss
            elif app.stitchList[app.selectedStitchIndex] == 'ss':
                if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
                    stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
                   app.centers[app.selectedStitchIndex] = (dotX, dotY)
            # all other stitches
            else:
                (dotX, dotY) = app.invisibleDots[closestPointIndex]
                (rdotX, rdotY) = app.graphDots[closestPointIndex]
                (stitchX, stitchY) = app.centers[app.selectedStitchIndex]
                Rotation = app.rotation[app.selectedStitchIndex]
                if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                    stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                    if Rotation  == 3:
                         app.centers[app.selectedStitchIndex] = (rdotX+15, (rdotY))
                    elif Rotation  == 4  or Rotation  == 2:
                        app.centers[app.selectedStitchIndex] = (dotX-15, (dotY+15))
                    elif Rotation  == 1  or Rotation  == 5:
                         app.centers[app.selectedStitchIndex] = (dotX+15, (dotY+15))
                    else:
                        app.centers[app.selectedStitchIndex] = (rdotX, rdotY+15)
            