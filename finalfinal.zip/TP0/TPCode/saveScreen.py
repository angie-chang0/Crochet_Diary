from cmu_graphics import *

def saveFuncts(app):
    app.backHighlight = False
    app.isfileHighlight = False 
    app.selectedSaveIndex = -1
    app.isClearSave = False
    app.clearSaveScreen = False
    with open("save1.txt", "r") as file1:
        app.data1 = file1.read()
    app.save1Name = ''
    app.save1centers = [ ]
    app.save1type = [ ]
    app.save1rot = [ ]
    app.save1color = [ ]
    if app.data1 != '':
        checkSave1Contents(app)
    app.saves = [(395, 100)]

def getSaveIndex(app, mouseX, mouseY):
    for i in range(len(app.saves)-1, -1, -1):
        xrect,yrect = app.saves[i]
        x0 = xrect - 420
        x1 = xrect + 300
        y0 = yrect - 420
        y1 = yrect + 300
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    



def drawSaveFiles(app):
    color = 'white'
    for i in range(len(app.saves)):
        x,y = app.saves[i]
        if app.selectedSaveIndex == i:
            color = 'lightGreen'
        drawRect(x, y, 300, 420, fill = color, border = 'cornflowerBlue')

    if app.data1 == '':
        drawLabel('empty save', 547,400, size = 40, font = 'Arial Rounded MT', align = 'center')
    else:
        drawLabel(f'{app.save1Name}', 547,400, size = 40, font = 'Arial Rounded MT', align = 'center')
    drawLabel('save file',535,50, size = 50,font = 'Arial Rounded MT', align = 'center')
    w,h = getImageSize(app.yarnball)
    drawImage(app.yarnball, 395, 100, width = w//2, height = h//2)

def drawBackButton(app): 
    if app.backHighlight == True:
      color = 'lightGreen'
      isBold = True
    else: 
      color = 'lightCyan' 
      isBold= False
    drawRect(920, 30, 125, 50, fill = color, border = 'cornflowerBlue')
    drawLabel('back', 985,55, size = 20, font = 'Arial Rounded MT', align = 'center')

def drawClearSave(app):
    if app.clearSaveScreen == True:
        color = 'lightGreen'
    else:
        color = 'white'
    drawRect(750,430, 200,50, fill = color, border = 'cornflowerBlue')
    drawLabel('clear save', 840,455, size = 20, font = 'Arial Rounded MT', align = 'center')

def savePresses(app, mouseX, mouseY):
    if (mouseX <= 695 and mouseX >= 395) and (mouseY <= 520 and mouseY >= 100):
        app.designName = app.save1Name
        app.stitchList = app.save1type
        app.centers = app.save1centers
        app.rotation = app.save1rot
        app.color = app.save1color
        app.saveScreen = False
        app.drawingScreen = True
    


def checkSave1Contents(app):
    app.save1Name, a, b, c, d = app.data1.split('/')
    app.save1centers = eval(a)
    app.save1type = eval(b)
    app.save1rot = eval(c)
    app.save1color = eval(d)

