from cmu_graphics import *

def editScreenVariables(app):
    app.hook = [(165, 263), (285, 263), (405, 263), (525, 263), (645, 263), (765, 263)]
    app.hookColor = 'white'       
    app.selectedhookIndex = 0

    app.yarn = [(165, 425), (285, 425), (405, 425), (525, 425), (645, 425), (765, 425)]
    app.yarnColor = 'white'       
    app.selectedyarnIndex = 0

  
    app. isNewName = False 
    app.editBG = 'editScreen.png'
    app.designName = ''
    app.hookColor = 'white'
    app.hookSize = 3.5
    app.yarnSize = 1
    app.tension = 0 


def drawOptions(app):
    drawImage(app.editBG, 0, 0)

    drawhooks(app)
    drawyarn(app)
    drawLabels(app)
    color = 'white'
    borderSize = 1
    if app.isNewName == True:
        color = 'lightGreen'
        borderSize = 5
    else: 
        color = 'white'
        borderSize = 1

    drawRect(450, 115, 370, 55, fill = color, border = 'cornflowerBlue')
    drawLabel(f'{app.designName}', 465, 140, align = 'left', size = 30, 
              borderWidth = borderSize, font = 'caveat', fill = 'cornflowerBlue')
    
    # Im finished button
    if app.isHighlighting == True:
        fincol = 'cornflowerBlue'
        isBold = True
    else: 
        fincol = 'lightCyan'
        isBold= False
    drawRect(930, 486, 150, 50, fill= fincol, border = 'black')
    drawLabel('Done', 995, 511, fill = 'black', size = 25, bold = isBold, font = 'montserrat')

def drawhooks(app):
    for i in range(len(app.hook)):
        color = app.hookColor
        xrect, yrect = app.hook[i]
        if app.selectedhookIndex == i:
            color = 'lightGreen'
        drawRect(xrect,yrect,110,60,fill=color,border='cornflowerBlue')   

def gethookIndex(app, mouseX, mouseY):
    for i in range(len(app.hook)-1, -1, -1):
        xrect,yrect = app.hook[i]
        x0 = xrect - 10
        x1 = xrect + 110
        y0 = yrect - 10
        y1 = yrect + 110
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def drawyarn(app):
    for i in range(len(app.yarn)):
        color = app.yarnColor
        xrect, yrect = app.yarn[i]
        if app.selectedyarnIndex == i:
            color = 'lightGreen'
        drawRect(xrect,yrect,110,60,fill=color,border='cornflowerBlue') 

def getyarnIndex(app, mouseX, mouseY):
    for i in range(len(app.yarn)-1, -1, -1):
        xrect,yrect = app.yarn[i]
        x0 = xrect - 10
        x1 = xrect + 110
        y0 = yrect - 10
        y1 = yrect + 110
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def assignhooksize(app):
    if app.selectedhookIndex == 0:
        app.hookSize = 0.2
    elif app.selectedhookIndex == 1:
        app.hookSize = 0.3
    elif app.selectedhookIndex == 2:
        app.hookSize = 0.5
    elif app.selectedhookIndex == 3:
        app.hookSize = 0.7
    elif app.selectedhookIndex == 4:
        app.hookSize = 1
    elif app.selectedhookIndex == 5:
        app.hookSize = 1.4
        
def assignyarnsize(app):
    if app.selectedyarnIndex == 0:
        app.yarnSize = 0.2
    elif app.selectedyarnIndex == 1:
        app.yarnSize = 0.5
    elif app.selectedyarnIndex == 2:
        app.yarnSize = 1
    elif app.selectedyarnIndex == 3:
        app.yarnSize = 2
    elif app.selectedyarnIndex == 4:
        app.yarnSize = 3
    elif app.selectedyarnIndex == 5:
        app.yarnSize = 5


def drawLabels(app):

    #hook
    drawLabel('3.5 mm',220,293, align = 'center', size = 20, fill='cornflowerBlue')
    drawLabel('4 mm',340,293, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('5 mm',460,293, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('6 mm',580,293, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('8 mm',700,293, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('10 mm',820,293, align = 'center', size = 20,fill='cornflowerBlue')

    #yarn
    drawLabel('Lace',220,455, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('Fine',340,455, align = 'center', size = 20, fill='cornflowerBlue')
    drawLabel('Light',460,455, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('Medium',580,455, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('Bulky',700,455, align = 'center', size = 20,fill='cornflowerBlue')
    drawLabel('Chunky',820,455, align = 'center', size = 20,fill='cornflowerBlue')

def main():
  runApp(width=1100, height=560)

# main()

    