from cmu_graphics import *
from dimCalc import *
from getlvl import*
import random

def templates(app, key):
    pass

    if key == 'q':
        convertToCoords(app)
        print(app.Coords)



def tempFuncts(app):
    app.isRandTemp = False 
    app.randSize = ''
    app.newRandSize = False
    app.computeDesign = False 
    app.randCol = 'white'

    app.lvl1 = dict()
    app.lvl2 = dict()
    app.lvl3 = dict()
    app.lvl4 = dict()
    app.lvl5 = dict()
    app.lvl6 = dict()
    app.lvl7 = dict()




    

def randTemplate(app):
    getlvl(app)
    centers = [ ]
    type = [ ]
    rot = [ ]
    x = getValue(app)
    for r in range(x+1):
        if r == 0:
            centers += [(420, 275), (435, 260), (450, 275), (435, 290)]
            type += ['chain', 'chain', 'chain', 'chain']
            rot += [0, 3, 0, 3]
        if r == 1:
            v = random.randrange(1,5)
            a,b,c = app.lvl1[v]
            centers += a
            type += b
            rot += c
        if r == 2:
            v = random.randrange(1,5)
            a,b,c= app.lvl2[v]
            centers += a
            type += b
            rot += c
        if r == 3:
            v = random.randrange(1,5)
            a,b,c = app.lvl3[v]
            centers += a
            type += b
            rot += c
        if r == 4:
            v = random.randrange(1,5)
            a,b,c= app.lvl4[v]
            centers += a
            type += b
            rot += c
        if r == 5:
            v = random.randrange(1,4)
            a,b,c= app.lvl5[v]
            centers += a
            type += b
            rot += c
        # if r == 6:
        #     v = random.randrange(1)
        #     a,b,c = app.lvl6[v]
        #     centers += a
        #     type += b
        #     rot += c
        # if r == 7:
        #     v = random.randrange(1)
        #     a,b,c= app.lvl7[v]
        #     centers += a
        #     type += b
        #     rot += c
        
    app.centers = centers
    app.stitchList = type
    app.rotation = rot
    app.color = [5] * (len(app.centers))
    print(len(app.centers), len(app.stitchList), len(app.rotation), len(app.color))
        


def getValue(app):
    if app.randSize != '':
        return int(app.randSize)
    else:
        return random.randrange(2,8)


def drawRandOptions(app):
    color = 'white'
    borderSize = 1
    if app.newRandSize == True:
        color = 'lightGreen'
        borderSize = 5
    else: 
        color = 'white'
        borderSize = 1

    drawRect(780, 300, 70, 40, fill = color, border = 'cornflowerBlue')
    drawLabel(f'{app.randSize}', 815, 320, align = 'center', size = 15, 
              borderWidth = borderSize, font = 'Arial Rounded MT', fill = 'cornflowerBlue')
    drawLabel('enter a value (2-7) for the size of the design', 775, 275, align = 'left', font = 'Arial Rounded MT',)
    drawLabel('or leave blank for a random number', 775, 287, align = 'left', font = 'Arial Rounded MT',)
    drawLabel('when finished press enter!', 865, 320, align = 'left', font = 'Arial Rounded MT',)


