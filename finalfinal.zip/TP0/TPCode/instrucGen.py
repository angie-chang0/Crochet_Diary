from cmu_graphics import *
from dimCalc import*
import copy
  


def intsructionsFuncts(app):
    app.isCastOn = False
    app.isCastOff = False 
    app. instr = [ ]
    app.printinstr = False
    app.dist = dict()
    app.sortedStitchName = [ ]
    app.sortedStitches = [ ]
    app.sortedType = [ ]
    app.printing = dict()
    app.validDesign = None
    app.isDoneGenerate = True


def checkForCasts(app):
    makeTable(app)
    graph = app.graphTable
    rows, cols = len(graph), len(graph[0])
    convertToCoords(app)
    if app.Coords == None:
        return None
    if app.stitchList.count('castOn') != 1:
        return None
    on = app.stitchList.index('castOn')
    (cx,cy) = app.centers[on]

    if app.stitchList.count('castOff') != 1:
        return None
    
    off = app.stitchList.index('castOff')
    (ox,oy) = app.centers[off]

    return (cx,cy), (ox,oy)
         
def generate(app):
    (cx,cy), (ox,oy) = checkForCasts(app)
    di = [ ]
   
    for i in range(len(app.centers)):
        (x,y) = app.centers[i] 
        t = app.stitchList[i]
        f = distance(cx,cy,x,y)
        app.dist[f] = (x,y), t
        di.append(f)

    di.sort()
 
    for i in di:
        x = app.dist.get(i)
        app.sortedStitches.append(i)


    getCoords(app)
    sortIntoDict(app)
    app.isDoneGenerate = True

def getCoords(app):
    for i in app.sortedStitches:
        if i in app.dist:
            s, t = app.dist[i]
            app.sortedType.append(s)
            app.sortedStitchName.append(t)


def sortIntoDict(app):
    list = copy.copy(app.sortedStitchName)
    while 'castOn' in app.sortedStitchName:
        x = app.sortedStitchName.index('castOn')
        app.sortedStitchName.pop(x)
    while 'castOff' in app.sortedStitchName:
        x = app.sortedStitchName.index('castOff')
        app.sortedStitchName.pop(x)
    print(app.sortedStitchName)

def drawInstructions(app):
    drawLabel('Instructions',535,50, size = 50,font = 'Arial Rounded MT', align = 'center')
    
    drawLabel(f'stitch {app.sortedStitchName}',50, 100, font = 'Arial Rounded MT', align = 'left')

def distance(x0, y0, x1, y1):
    return ((x1 - x0)**2 + (y1 - y0)**2)**0.5


def instrButton(app): 
    color = 'lightCyan' 
    drawRect(920, 30, 125, 50, fill = color, border = 'cornflowerBlue')
    drawLabel('back', 985,55, size = 20, font = 'Arial Rounded MT', align = 'center')

            
