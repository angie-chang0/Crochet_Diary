from cmu_graphics import *
from st import *
from snapstitch import *
from rotate import *
from editScreen import *
from startScreen import *
from dimCalc import*
from colors import*
from instrucGen import *
from templates import *
from saveScreen import *

#CITATIONS
#all drawings are made my me
#stitch font is from here: https://www.onlinewebfonts.com/download/d81b9d50cf89e41a86a96e3e69d2cced
# arial rounded = https://www.download-free-fonts.com/details/92774/arial-rounded-mt-bold
#please download .tff files to properly run code

#line 276-285: get index code I took from my own code in problem 'reshape the polygon' (and any other code follwing that format)
#instrucGen.py: 86-87: distance formula I took from class notes 

def onAppStart(app):
    #start screen variables
    app.startScreen = True
    app.title = 'start.png'
    app.isHighlighting = False

    app.saveScreen = False
    app.isSaveHighlighting = False
   

    #editScreenVariables
    app.overWordLimit = False
    app.editScreen = False
    editScreenVariables(app)

    #drawing screen varibles 
    app.button = ([(30, 100), (30, 170), (30, 240), (30, 310), (100, 100), 
                (100, 170), (100, 240), (100, 310)])
    app.buttonColor = 'white'         
    app.drawingScreen = False
    app.selectedButtonIndex = -1
    app.stitchName = 'stitch displayed here'
    app.canvasbk = 'canvasbk.png'
    app.castOn = 'castOn.png'
    app.dc = 'doubleCrochet.PNG'
    app.tc = 'tripleCrochet.PNG'
    app.sc = 'singleCrochet.PNG'
    app.hdc = 'halfdoubleCrochet.PNG'
    app.yarnball = 'yarnball.png'
    app.stitchNames = dict()
    app.graphDots = [ ]
    app.invisibleDots = [ ]

    #end screen
    app.endScreen = False 
   
   #rotate stitches variables
    app.rotateButtons = [(30, 380), (30, 416), (30, 454), (96, 380), (96, 416), (96, 454)]
    app.rotColor = 'white'
    app.isRotate = False
    app.selectedRotIndex = 0

    app.selectedStitchIndex = -1
    
    #data on stitches
    app.stitchList = [ ]
    app.centers = [ ]
    app.shapes = [ ]
    app.rotation = [ ]
    app.color = [ ]

    app.showChainOptions = False
    app.showSCOptions = False
    app.showHDCOptions = False
    app.showDCOptions = False
    app.TC = False

    app.autosnap = False 

    #calculateDimFuncts
    dimVariables(app)
    app.isCalculating = False 

    #buttons 
    calcbutton = button(770, 20, 140, 100)
    back2editbutton = button(920, 20, 140, 100)
    instructsbutton = button(770, 130, 140, 100)
    strengthbutton = button(920, 130, 140, 100)

    app.functButtons = [calcbutton, back2editbutton, instructsbutton, strengthbutton]

    #colors
    colorFuncts(app)
    
    intsructionsFuncts(app)
    app.isgenerating = False 

    app.isSnap = False
    app.isClear = False

    #generate random template functions 
    tempFuncts(app)

    saveFuncts(app)

   


def redrawAll(app):
    drawRect(0,0, 1100, 560, fill = 'aliceBlue')
    if app.startScreen is True:
        drawTitle(app)
        startButton(app)
        saveButton(app)

    if app.editScreen is True:
        for i in range(6):
            xrect=170+i*120
            drawRect(xrect,425,110,65,border='cornflowerBlue')
        drawOptions(app)  

        
        if app.overWordLimit == True:
            drawNameWarning(app)  
    if app.saveScreen is True:
        drawSaveFiles(app)
        drawBackButton(app)
        drawClearSave(app)
        
    if app.drawingScreen is True:
        drawImage(app.canvasbk,180,20)
        boardRow(app)
        drawBack(app)
        drawCastSelection(app)
        drawButtons(app)
        drawTrash(app)
        drawStitches(app)
        boardINV(app)
        drawName(app)
        drawrotateimg(app)
        drawClearAll(app)
        drawDoneScreen(app)

        #canvas border
        drawRect(180, 20, 570, 530, fill = None, border = 'cornflowerBlue')

        #draw curr stich selected
        drawRect(30,60, 130, 30,fill='white',border='cornflowerBlue')
        drawLabel(f'{app.stitchName}',94, 75, align = 'center',
                   font = 'Arial Rounded MT')
                #draw colors
        drawRect(770, 370, 130, 170, fill = 'white', border = 'cornflowerBlue')
        drawLabel('colors', 840, 385, font = 'Arial Rounded MT', size = 20)
        #console
        drawRect(770, 240, 290, 120, fill = 'white', border = 'cornflowerBlue')
        drawLabel('console',915, 255, fill = 'black', bold = True,
                   align = 'center', size = 20, font = 'Arial Rounded MT')
        #draw autosnap
        drawautosnap(app)
        #draw color buttons
        drawColorButts(app)
        #functButtons
        drawFunctButtons(app)
        #draw stitches on board 
        for i in range(len(app.stitchList)):
            type = app.stitchList[i]
            st = stitch(type)
            (mx, my) = app.centers[i]
            angle = app.rotation[i]
            color = app.color[i]
            st.draw(app, mx,my, angle, color)
    #dimCalc functs
    # if app.drawingScreen == True:
        if app.isCalculating == True:
            drawDimLines(app)
        if app.notValid == True:
            drawNotValid(app)
        
        if app.isRandTemp == True:
            drawRandOptions(app)
        
        if app.isClearSave == True:
            drawLabel('saved!' ,915, 300, font = 'Arial Rounded MT', size = 15, fill = 'red')
    if app.endScreen == True:
        drawInstructions(app)
        instrButton(app)
        

def drawDoneScreen(app):
    drawRect(910, 480, 70, 45 , fill = 'powderBlue', border = 'cornflowerBlue')
    drawLabel('back',947, 499, align = 'center', font = 'Arial Rounded MT', size = 15)

    drawRect(985, 480, 70, 45 , fill = 'powderBlue', border = 'cornflowerBlue')
    drawLabel('done!',1018, 499, align = 'center', font = 'Arial Rounded MT', size = 15)
def drawClearAll(app):
    drawRect(660, 520, 70, 25, fill = None, border = 'darkRed')
    if app.isClear == True:
        drawRect(660, 520, 70, 25, fill = 'darkRed')
    drawLabel('clear all', 670, 533, align = 'left', font = 'Arial Rounded MT')

def drawFunctButtons(app):
    for i in app.functButtons:
        i.draw()
    if app.isCalculating == True:
        drawRect(770, 20, 140, 100, fill = 'lightGreen')
    if app.isgenerating == True:
        drawRect(770, 130, 140, 100, fill = 'lightGreen')
    if app.isSnap == True:
        drawRect(920, 130, 140, 100, fill = 'lightGreen')
    drawLabel('Edit', 990, 60, font = "Arial Rounded MT", size = 20)
    drawLabel('Gauge', 990, 80, font = "Arial Rounded MT", size = 20)
    drawLabel('Calculate', 840, 70, font = "Arial Rounded MT", size = 20)
    drawLabel('Snap',990,170,font = "Arial Rounded MT", size = 20)
    drawLabel('Stitches',990,190,font = "Arial Rounded MT", size = 20)
    drawLabel('Instructions',840,180, font = "Arial Rounded MT", size = 20)
    if app.isRandTemp == True:
        color = 'lightGreen'
    else:
        color = app.randCol
    if app.isClearSave == True:
        savecol = 'lightGreen'
    else:
        savecol = 'white'
    drawRect(910, 370, 150, 45, fill = color, border = 'cornflowerBlue')
    drawLabel('Generate Random',985, 393, align = 'center', font = 'Arial Rounded MT', size = 15)
    drawRect(910, 425, 150, 45, fill = savecol, border = 'cornflowerBlue')
    drawLabel('save design',985, 450, align = 'center', font = 'Arial Rounded MT', size = 15)

def drawautosnap(app):
        color = 'white'
        if app.autosnap == True:
            color = 'powderBlue'
        drawRect(30, 500, 130, 30, fill = color, border = 'cornflowerBlue' )
        drawLabel('auto-snapping', 90, 515, font = 'Arial Rounded MT')      

def drawName(app):
    drawRect(30, 20, 130, 35, fill = 'powderBlue', border = 'cornflowerBlue')
    drawLabel(f'{app.designName}',94, 40, align = 'center', size = 15, 
              font = 'Arial Rounded MT', bold = True)

def boardINV(app):
    for col in range(16):
        y = 65+col*30
        for row in range(18):
            x = 225+row*30
            app.invisibleDots.append((x,y))
            drawCircle(x, y, 2, fill = None)

def drawTrash(app):
    drawRect(180, 515, 570, 35, fill = 'salmon', border = None)
    drawLabel('Trash',455, 530, align = 'center', size = 20)

        
def boardRow(app):
    for col in range(16):
        y = 50+col*30
        for row in range(18):
            x = 210+row*30
            app.graphDots.append((x,y))
            drawCircle(x, y, 2, fill = 'cornflowerBlue')

def drawButtons(app):
    for i in range(len(app.button)):
        color = app.buttonColor
        xrect, yrect = app.button[i]
        if app.selectedButtonIndex == i:
            color = 'steelBlue'
        drawRect(xrect,yrect,60,60,fill= None,border='cornflowerBlue')  

def drawBack(app):
    for i in range(len(app.button)):
        color = app.buttonColor
        xrect, yrect = app.button[i]
        drawRect(xrect,yrect,60,60,fill= 'white')  
  


def getButtonIndex(app, mouseX, mouseY):
    for i in range(len(app.button)-1, -1, -1):
        xrect,yrect = app.button[i]
        x0 = xrect - 9
        x1 = xrect + 60
        y0 = yrect - 9
        y1 = yrect + 60
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    

def onMousePress(app, mouseX, mouseY):
    if app.saveScreen != True:
            app.clearSaveScreen = False

        #startScreen
    if app.startScreen == True:
        if ((mouseX >= 500 and mouseX <= 850)
            and (mouseY >= 320 and mouseY <=400)):
            app.editScreen = True
            app.startScreen = False 
        if ((mouseX >= 600 and mouseX <= 725)
            and (mouseY >= 410 and mouseY <=450)):
            app.startScreen = False 
            app.saveScreen = True
    # saveScreen functions 
    elif app.saveScreen == True:
        if (mouseX >= 920 and mouseX <= 1045) and (mouseY >= 30 and mouseY <=80):
            app.saveScreen = False
            app.startScreen = True
        
        savePresses(app, mouseX, mouseY)
        app.clearSaveScreen = True
        if (mouseX >= 750 and mouseX <= 950) and (mouseY >= 430 and mouseY <=480):

            with open("save1.txt", "w") as file1:
                file1.write('')
            saveFuncts(app)
        
        if getSaveIndex(app, mouseX, mouseY) != None: 
            app.selectedsaveIndex = getSaveIndex(app,mouseX, mouseY)

    # editScreen Functions
    elif app.editScreen == True:
        if gethookIndex(app, mouseX, mouseY) != None: 
            app.selectedhookIndex = gethookIndex(app,mouseX, mouseY)
            assignhooksize(app)
        
        if getyarnIndex(app, mouseX, mouseY) != None: 
            app.selectedyarnIndex = getyarnIndex(app,mouseX, mouseY)
            assignyarnsize(app)

        if (mouseX <= 820 and mouseX >= 450) and (mouseY <=170 and mouseY >= 115):
            app.isNewName = True 
        elif app.isNewName == True:
            app.isNewName = False 
    
    #mainscreen functions
    if app.drawingScreen == True:
        if app.notValid == True:
            app.notValid = False

        if getButtonIndex(app, mouseX, mouseY) != None: 
            app.selectedButtonIndex = getButtonIndex(app,mouseX, mouseY)
        getStitchName(app)
        
        app.selectedRotIndex = 0   
        if getRotIndex(app, mouseX, mouseY) != None:
                app.selectedRotIndex = getRotIndex(app,mouseX, mouseY)
        
        if getColorIndex(app,mouseX, mouseY) != None:
            app.selectedColorIndex = getColorIndex(app, mouseX, mouseY)

        if getStitchIndex(app, mouseX, mouseY) != None:
            app.selectedStitchIndex = getStitchIndex(app, mouseX, mouseY)
            
            if app.selectedColorIndex != -1:
                app.color[app.selectedStitchIndex] = app.selectedColorIndex
                app.selectedColorIndex = -1

        elif app.isRotate == True:
            if len(app.centers) == len(app.rotation):
                curr = (len(app.centers))-1
                app.rotation[curr] = app.selectedRotIndex  
                
        else:
            pressFuncts(app)

        if (mouseX <= 160 and mouseX >= 30) and (mouseY <= 530 and mouseY >= 500):
            if app.autosnap == True:
                app.autosnap = False 
            else:
                app.autosnap = True

        #calculate Button 
        if (mouseX <= 910 and mouseX >= 770) and (mouseY <= 120 and mouseY >= 20):
            getPoint(app)
            if len(app.centers) > 4:
                app.Coords = [ ]
                calculate(app)
                if app.isCalculating == False:
                    app.isCalculating = True
                else:
                    app.isCalculating = False       
            if len(app.centers) <= 4:
                app.notValid = True  
        #snapStitches
        if (mouseX <= 1060 and mouseX >= 920) and (mouseY <= 230 and mouseY >= 130):
            if app.isSnap == True:
                app.isSnap= False 
            else:
                app.isSnap = True
                getPoint(app)
        #back to edit screen
        if (mouseX <= 1060 and mouseX >= 920) and (mouseY <= 120 and mouseY >= 20):
            app.drawingScreen = False
            app.editScreen = True
        #intructions
        if (mouseX <= 910 and mouseX >= 770) and (mouseY <= 230 and mouseY >= 130):
            if checkForCasts(app) != None:
                generate(app)
            if app.isDoneGenerate == True:
                app.drawingScreen = False
                app.endScreen = True



        # # clearing all stitches
        if (mouseX <= 730 and mouseX >= 660) and (mouseY <= 545 and mouseY >= 520):
            app.isClear = True
            app.isRotate = False
            app.showChainOptions = False
            app.showSCOptions = False
            app.showHDCOptions = False
            app.showDCOptions = False
            app.TC = False
            app.centers = [ ]
            app.stitchList = [ ]
            app.rotation = [ ]
            app.color = [ ]
        #random stitch generation mousePresses 
        if (mouseX <= 1060 and mouseX >= 910) and (mouseY <= 415 and mouseY >= 370):
            if app.isRandTemp == True:
                app.isRandTemp= False 
            else:
                app.isRandTemp = True
        if app.isRandTemp == True:
            if (mouseX <= 850 and mouseX >= 780) and (mouseY <=340 and mouseY >= 300):
                    app.newRandSize = True 
            elif app.newRandSize == True:
                    app.NewRandSize = False 
        #back to startScreen
        if (mouseX <= 980 and mouseX >= 910) and (mouseY <=525 and mouseY >= 480):
            app.drawingScreen = False
            app.startScreen = True 


        # saveFunction
        saveDesign(app,mouseX,mouseY)
    
        if (mouseX <= 1055 and mouseX >= 985) and (mouseY <=525 and mouseY >= 480):
            saveDesign(app,mouseX,mouseY)
            app.drawingScreen = False
            app.startScreen=True
    if app.endScreen == True:
            if (mouseX >= 920 and mouseX <= 1045) and (mouseY >= 30 and mouseY <=80):
                app.endScreen = False
                app.drawingScreen = True    
    if app.editScreen ==True:
        if (mouseX <= 1080 and mouseX >= 930) and (mouseY <=536 and mouseY >= 486):
            app.drawingScreen = True
            app.editScreen = False 
            app.startScreen = False

def saveDesign(app,mouseX,mouseY):
    if (mouseX <= 1060 and mouseX >= 910) and (mouseY <=470 and mouseY >= 425):
        app.isClearSave = True
        if app.centers != []:
            with open("save1.txt", "w") as file1:
                file1.write(f'{app.designName}/{app.centers}/{app.stitchList}/{app.rotation}/{app.color}')


        
def getStitchIndex(app, mouseX, mouseY):
    if len(app.centers) != 0:
        for i in range(len(app.centers)-1, -1, -1):
            cx, cy = app.centers[i]
            w,l = determineStitchType(app, i)
            x0 = cx - w
            x1 = cx + w
            y0 = cy - l
            y1 = cy + l
            if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
                return i
    return None  

def onMouseDrag(app, mouseX, mouseY):
    app.isRotate = False
    app.showChainOptions = False
    app.showSSOptions = False
    app.showSCOptions = False
    app.showHDCOptions = False
    app.showDCOptions = False
    app.TC = False 
    if app.selectedStitchIndex != -1:  
        if mouseX < 180: mouseX = 185
        elif mouseX > 750:mouseX = 730
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.centers[app.selectedStitchIndex] = (mouseX, mouseY)
        if app.autosnap == True:
            getPoint(app)
        snapCasts(app)

def onMouseRelease(app, mouseX, mouseY):
    app.selectedButtonIndex = -1    
    trashStitches(app, mouseX, mouseY)
    app.isClear = False 
    app.isSnap = False
    app.isClearSave = False 
    app.clearSaveScreen = False

def onMouseMove(app, mouseX, mouseY):
    # startScreen
    if app.startScreen == True:
        if (mouseX >= 500 and mouseX <= 850) and (mouseY >= 320 and mouseY <=400):
            app.isHighlighting = True
        else:
            app.isHighlighting = False  
    if app.startScreen == True:
        if (mouseX >= 600 and mouseX <= 725) and (mouseY >= 410 and mouseY <=450):
            app.isSaveHighlighting = True
        else:
            app.isSaveHighlighting = False  
    # saveScreen
    if app.saveScreen == True:
        if (mouseX >= 920 and mouseX <= 1045) and (mouseY >= 30 and mouseY <=80):
            app.backHighlight= True
        else:
            app.backHighlight = False  
      
    #editScreen 
    if app.editScreen == True:
        if (mouseX >= 930 and mouseX <= 1080) and (mouseY >= 486 and mouseY <=536):
            app.isHighlighting = True
        else:
            app.isHighlighting = False 
    if (mouseX <= 730 and mouseX >= 660) and (mouseY <= 545 and mouseY >= 520):
        app.isClear = True 


def onKeyPress(app, key):
    # for naming design
    if app.editScreen == True:
        if app.isNewName == True and len(app.designName) <= 11:
            if key == 'space':
                app.designName += ' '
            elif key.isalpha() and key is not 'backspace' and key is not 'enter' and key is not 'space':
                app.designName += key
        if key == 'backspace' and app.designName != '':
            app.designName =  app.designName[:-1]
            if app.overWordLimit == True:
                app.overWordLimit = False
        elif key == 'enter':
            app.isNewName = False
        if len(app.designName) > 11:
            app.overWordLimit = True  

    #for entering values into rand generator 
    if app.drawingScreen == True:
        if key == 'p':
            print(app.centers)
            print(app.stitchList)
            print(app.rotation)
            print(app.color)
        templates(app,key)
        if app.newRandSize == True:
            if (key.isdigit() and (key =='2' or key =='3' or key =='4' or
                key =='5' or key == '6' or key == '7') and key is not 'backspace' 
                and key is not 'enter' and key is not 'space' and (len(app.randSize) <1)):
                app.randSize += key
        if key == 'backspace' and app.randSize != '':
            app.randSize =  app.randSize[:-1]
        elif key == 'enter':
            app.newRandSize = False
            app.isRandTemp = False
            randTemplate(app)
            app.computeDesign = True 
            app.randSize = ''

    
def main():
  runApp(width=1100, height=560)

main()
