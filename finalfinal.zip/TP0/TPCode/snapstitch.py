from cmu_graphics import *
from dimCalc import *
import copy

def getPoint(app):
    # print('hi')
    # graph = copy.copy(app.graphDots)
    # graph = set(graph)

    for stitch in range(len(app.centers)):
        (stitchX, stitchY) = app.centers[stitch]
        Rotation = app.rotation[stitch]
        graph = copy.copy(app.graphDots)
        graph = set(graph)
        invgraph = copy.copy(app.invisibleDots)
        invgraph = copy.copy(invgraph)
        while len(graph) != 0:
            (dotX, dotY) = graph.pop()
            (rdotX, rdotY) = invgraph.pop()
            if app.stitchList[stitch] == 'chain':
                if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                    stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                        if Rotation == 3:

                                app.centers[stitch] = (dotX+15, (dotY))
                        elif Rotation == 4  or Rotation == 2:
                            app.centers[stitch] = (dotX+15, (dotY-15))

                        elif Rotation == 1  or Rotation == 5:
                            app.centers[stitch] = (dotX+15, (dotY+15))

                        else:
                            app.centers[stitch] = (dotX, (dotY+15))
  
            elif app.stitchList[stitch] == 'ss':
                    if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
                        stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
                        app.centers[stitch] = (dotX, dotY)
            
            elif (app.stitchList[stitch] != 'ss' and app.stitchList[stitch] != 'chain' 
                  and app.stitchList[stitch] != 'castOn' and app.stitchList[stitch] != 'castOff'):
                    if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                        stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                            if Rotation  == 3:                    
                                app.centers[stitch] = (dotX, (dotY+15))
                            elif Rotation  == 4  or Rotation  == 2:
                                if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                                    stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                                        app.centers[stitch] = (dotX-15, (dotY+15))
                            elif Rotation  == 1  or Rotation  == 5:
                                if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
                                    stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
                                        app.centers[stitch] = (dotX+15, (dotY+15))
                            else:
                                app.centers[stitch] = (dotX+15, dotY)

def snapCasts(app):
    if app.isCastOn == True and app.isCastOff == True:
        i = app.stitchList.index('castOn')
        (cox, coy) = app.centers[i]
        n = app.stitchList.index('castOff')
        (cfx, cfy) = app.centers[n]
        list = copy.copy(app.centers)
            # list.pop((cox,coy))
            # list.pop((cfx,cfy))
        for stitch in range(len(list)):
            (dotX, dotY) = app.centers[stitch]
            if (coy <= (dotY + 20) and coy >= (dotY - 20) and
                cox <= (dotX + 20) and cox >=(dotX - 20)):
                    app.centers[i] = (dotX, dotY)
            if (cfy <= (dotY + 13) and cfy >= (dotY - 13) and
                cfx <= (dotX + 13) and cfx >=(dotX - 13)):
                    app.centers[n] = (dotX, dotY)
                
        

       


# def getClosestPoint(app):

#         for closestPointIndex in range(len(app.graphDots)):
#             for stitch in range(len(app.centers)):
#                 (dotX, dotY) = app.graphDots[closestPointIndex]
#                 (stitchX, stitchY) = app.centers[stitch]
#                 Rotation = app.rotation[stitch]
#                 if app.stitchList[stitch] == 'chain':
#                     if (stitchY <= (dotY + 14.5) and stitchY >= (dotY - 14.5) and
#                         stitchX <= (dotX + 14.5) and stitchX >=(dotX - 14.5)):
#                         if Rotation == 3:
#                             app.centers[stitch] = (dotX+15, (dotY))
#                         elif Rotation == 4  or Rotation == 2:
#                             app.centers[stitch] = (dotX+15, (dotY-15))
#                         elif Rotation == 1  or Rotation == 5:
#                             app.centers[stitch] = (dotX+15, (dotY+15))
#                         else:
#                             app.centers[stitch] = (dotX, (dotY+15))
#                 # ss
#                 elif app.stitchList[stitch] == 'ss':
#                     if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
#                         stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
#                         app.centers[stitch] = (dotX, dotY)
#                 # all other stitches
#                 else:
#                     if (stitchY <= (dotY + 14.5) and stitchY >= (dotY - 14.5) and
#                         stitchX <= (dotX + 14.5) and stitchX >=(dotX - 14.5)):
#                         if Rotation == 3:
#                             app.centers[stitch] = (dotX, (dotY+15))
#                         elif Rotation == 4  or Rotation == 2:
#                             app.centers[stitch] = (dotX+15, (dotY-15))
#                         elif Rotation == 1  or Rotation == 5:
#                             app.centers[stitch] = (dotX+15, (dotY+15))
#                         else:
#                             app.centers[stitch] = (dotX+15, (dotY))

    # for closestPointIndex in range(len(app.graphDots)):
    #     if app.selectedStitchIndex != None:
    #         (dotX, dotY) = app.graphDots[closestPointIndex]
    #         (stitchX, stitchY) = app.centers[app.selectedStitchIndex]
    #         Rotation = app.rotation[app.selectedStitchIndex]
    #         # chain
    #         if app.stitchList[app.selectedStitchIndex] == 'chain':
    #             if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
    #                 stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
    #                 if Rotation == 3:
    #                     app.centers[app.selectedStitchIndex] = (dotX+15, (dotY))
    #                 elif Rotation == 4  or Rotation == 2:
    #                     app.centers[app.selectedStitchIndex] = (dotX+15, (dotY-15))
    #                 elif Rotation == 1  or Rotation == 5:
    #                     app.centers[app.selectedStitchIndex] = (dotX+15, (dotY+15))
    #                 else:
    #                     app.centers[app.selectedStitchIndex] = (dotX, (dotY+15))
    #         # ss
    #         elif app.stitchList[app.selectedStitchIndex] == 'ss':
    #             if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
    #                 stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
    #                app.centers[app.selectedStitchIndex] = (dotX, dotY)
    #         # all other stitches
    #         else:
    #             (dotX, dotY) = app.invisibleDots[closestPointIndex]
    #             (rdotX, rdotY) = app.graphDots[closestPointIndex]
    #             (stitchX, stitchY) = app.centers[app.selectedStitchIndex]
    #             Rotation = app.rotation[app.selectedStitchIndex]
    #             if (stitchY <= (dotY + 14) and stitchY >= (dotY - 14) and
    #                 stitchX <= (dotX + 14) and stitchX >=(dotX - 14)):
    #                 if Rotation  == 3:
    #                      app.centers[app.selectedStitchIndex] = (rdotX+15, (rdotY))
    #                 elif Rotation  == 4  or Rotation  == 2:
    #                     app.centers[app.selectedStitchIndex] = (dotX-15, (dotY+15))
    #                 elif Rotation  == 1  or Rotation  == 5:
    #                      app.centers[app.selectedStitchIndex] = (dotX+15, (dotY+15))
    #                 else:
                        # app.centers[app.selectedStitchIndex] = (rdotX, rdotY+15)